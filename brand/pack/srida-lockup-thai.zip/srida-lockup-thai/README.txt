Lockup คู่ชื่อไทย "สีดา"
- horizontal (แนวนอน) ใช้บนหัวเว็บ หัวเอกสาร · stacked (แนวตั้ง) เหมาะสำหรับพื้นที่สี่เหลี่ยม
- 4 แบบสี: color, on-dark, black, white
ตัวอักษรไทยคือ Prompt Bold (OFL) แปลงเป็นเส้นแล้ว
ไฟล์ -white และ -on-dark ใน PDF มีพื้นหมึก (#0B0B0C) รองไว้ เพราะ PDF ไม่มีพื้นโปร่งใสให้เห็นตัวอักษรขาว · PNG ทุกไฟล์พื้นโปร่งใส · SVG ตัวอักษรเป็นเส้น (outline) เปิดได้โดยไม่ต้องมีฟอนต์

Thai lockup: horizontal/stacked × color, on-dark, black, white. Thai letters are Prompt Bold, outlined.
PDFs of -white and -on-dark carry an ink (#0B0B0C) backing plate (PDF has no transparent page). PNGs are transparent. SVG text is outlined (no fonts needed).
