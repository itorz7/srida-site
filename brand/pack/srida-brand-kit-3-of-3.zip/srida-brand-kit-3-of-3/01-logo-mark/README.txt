Logo mark — ไอคอนฝรั่ง
แต่ละแบบมี SVG, PDF (เวกเตอร์สำหรับพิมพ์), PNG พื้นหลังโปร่งใส ขนาด 512/1024/2048 px
- srida-mark-color: สี ใช้ตั้งแต่ 48 px ขึ้นไป (มีเมล็ดและเส้นใบ)
- srida-mark-color-small: ใช้ 16–32 px (ตัดเมล็ด เปลือกและก้านหนาขึ้น)
- srida-mark-black / -white: สีเดียว สำหรับพิมพ์สีเดียว แกะสลัก ปั๊ม หรือวางบนพื้นเข้ม
เว้นที่ว่างรอบโลโก้อย่างน้อยเท่าความสูงของตัว s · ห้ามยืด หมุน เปลี่ยนสี หรือใส่เงา
ไฟล์ -white และ -on-dark ใน PDF มีพื้นหมึก (#0B0B0C) รองไว้ เพราะ PDF ไม่มีพื้นโปร่งใสให้เห็นตัวอักษรขาว · PNG ทุกไฟล์พื้นโปร่งใส · SVG ตัวอักษรเป็นเส้น (outline) เปิดได้โดยไม่ต้องมีฟอนต์

Logo mark: SVG, PDF (vector), transparent PNG 512/1024/2048. color = 48 px and up; color-small = 16–32 px; black/white = one-colour use.
PDFs of -white and -on-dark carry an ink (#0B0B0C) backing plate (PDF has no transparent page). PNGs are transparent. SVG text is outlined (no fonts needed).
