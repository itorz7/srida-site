เทมเพลต (ใช้ภาพบักสีดา 3D จริง + โลโก้ + พื้นสีเรียบ)
- business-card-front/back-90x55mm.pdf: นามบัตร 90x55 มม. แยกไฟล์ละหน้า ช่องชื่อ/ตำแหน่ง/โทร/อีเมลด้านหลังนามบัตรเป็นข้อความตัวอย่าง สามารถแก้ไขได้ (ระยะเผื่อตัดตก: หากส่งโรงพิมพ์ ให้ขยายพื้นหลังออกไป 3 มม.)
- letterhead-a4.pdf: หัวกระดาษ A4
- meeting-background-light/dark-1920x1080.png: พื้นหลังประชุมออนไลน์ (Zoom/Meet/Teams) เว้นพื้นที่ตรงกลางภาพสำหรับผู้พูด
- email-signature/: signature.html + srida-signature-logo.png
ข้อความตัวอย่างในเทมเพลต (ชื่อ นามสกุล ตำแหน่ง โทร อีเมล) กรุณาแทนที่ด้วยข้อมูลจริงก่อนนำไปใช้งาน

Business card PDFs (front/back, 90x55 mm), A4 letterhead PDF, two 1920x1080 meeting backgrounds and an HTML email signature. Placeholders (name, title, phone, email) must be replaced.
